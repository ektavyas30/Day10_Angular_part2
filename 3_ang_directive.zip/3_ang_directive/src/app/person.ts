export interface Person {
    id: number;
    name: string;
    gender?: string;
  }
  
  export const Persons: Person[] = [
    { id: 1, name: 'Dhruv', gender: 'Male'},
    { id: 2, name: 'Ekta', gender: 'Female' },
    { id: 3, name: 'Vimir', gender: 'Female' },
    { id: 4, name: 'Atharv',gender: 'Male'}
  ];
  